"""
Wrapper for AI server
"""
import json
import logging
import os
import random
import signal
import subprocess
import threading
import time

import requests
import toml
import websocket

with open("wrapper.toml", "r", encoding="utf-8") as f:
    config = toml.load(f)

API_URL = f"https://{config['server']['host']}/api/v1"
WS_URL = f"wss://{config['server']['host']}/ws"

SERVER_CODE = config["server"]["code"]
API_KEY = config["server"]["api_key"]

WEBUI_PATH = config["webui"]["path"]
WEBUI_ARGS = config["webui"]["args"]

FRP_PATH = config["frpc"]["path"]
FRP_BASE = config["frpc"]["base"]
FRP_TEMPLATE = config["frpc"]["template"]

DEBUG = config["server"]["debug"]

CWD = (
    config["webui"]["cwd"] if "cwd" in config["webui"] else WEBUI_PATH.rsplit("/", 1)[0]
)
LOCAL_PORT = config["frpc"]["template"]["proxies"][0]["localPort"]
ENV = os.environ.copy()
if "VIRTUAL_ENV" in ENV:
    del ENV["VIRTUAL_ENV"]

assert os.path.isfile(WEBUI_PATH), f"WebUI not found: {WEBUI_PATH}"
assert os.path.isfile(FRP_PATH), f"frpc not found: {FRP_PATH}"


class CustomFormat(logging.Formatter):
    red = "\x1b[31;1m"
    yellow = "\x1b[33;1m"
    green = "\x1b[32;1m"
    blue = "\x1b[36;1m"
    reset = "\x1b[0m"
    f = "%(asctime)s - %(name)s - %(message)s"

    FORMAT = {
        logging.DEBUG: blue + f + reset,
        logging.INFO: green + f + reset,
        logging.WARNING: yellow + f + reset,
        logging.ERROR: red + f + reset,
    }

    def format(self, record):
        log_fmt = self.FORMAT.get(record.levelno)
        formatter = logging.Formatter(log_fmt)

        return formatter.format(record)


ch = logging.StreamHandler()
ch.setFormatter(CustomFormat())

server_log = logging.getLogger("server-log")
server_log.setLevel(logging.DEBUG if DEBUG else logging.INFO)
server_log.addHandler(ch)


class Wrapper:
    """Wrapper for AI server"""

    def __init__(self, api_url, ws_url, code, api_key):
        self.api = AIApi(api_url, code, api_key)
        self.manager = AIManager()
        self.ws_url = ws_url

        ws_token = self.api.socket_token()

        if DEBUG:
            websocket.enableTrace(True)
        self.ws = websocket.WebSocketApp(
            f"{ws_url}?token={ws_token}",
            on_open=self.on_open,
            on_message=self.on_message,
            on_error=self.on_error,
            on_close=self.on_close,
        )

        self.ping_thread = threading.Thread(target=self.ping, daemon=True)
        self.ws.run_forever(ping_interval=30, ping_timeout=5, reconnect=1)

    ## Websocket callbacks

    def on_open(self, _ws):
        """Websocket is connected"""

        server_log.info("ws.on_open: Connected")

        if not self.ping_thread.is_alive():
            self.ping_thread.start()

        self.manager.cleanup()

        res = self.api.avail()

        if 200 == res.status_code:
            server_log.info("ws.on_open: Queue empty")
        elif 204 == res.status_code:
            server_log.info("ws.on_open: Queue not empty")
        else:
            server_log.warning(
                "ws.on_open.api_avail: [%s]: %s", res.status_code, res.text
            )

    def on_message(self, _ws, msg):
        """Websocket received message"""

        server_log.debug("ws.on_message: %s", msg)

        try:
            msg = json.loads(msg)
        except json.JSONDecodeError:
            server_log.debug("ws.on_message: Skip non-json message")
            return

        if "customerFindAIServer" == msg["event"]:
            uiid = random.randbytes(16).hex()
            self.handle_start(uiid)
        elif "customerStopAIServer" == msg["event"]:
            self.handle_stop()

    def on_error(self, _ws, error):
        """Websocket error"""
        server_log.error("ws.on_error: %s", error)

        ws_token = self.api.socket_token()
        self.ws.url=f"{self.ws_url}?token={ws_token}"

    def on_close(self, _ws, close_status, msg):
        """Websocket is closed"""
        server_log.error("ws.on_close [%s]: %s", close_status, msg)

        if self.ping_thread.is_alive():
            server_log.info("ws.on_close: Stopping ping thread")
            self.ping_thread.join(3)

        self.manager.cleanup()

    ## Message handlers

    def handle_start(self, uiid: str):
        """Start server"""

        if self.manager.is_running():
            server_log.warning("handle_start: Server already running")
            return

        server_log.info("handle_start: %s", uiid)

        share_url = self.manager.start(uiid)
        server_log.info(share_url)

        if share_url is None:
            return

        start = self.api.accept(share_url)

        if 204 == start.status_code:
            server_log.info("handle_start.api_accept: Ok")
        else:
            server_log.warning(
                "handle_start.api_accept [%s]: %s", start.status_code, start.text
            )

    def handle_stop(self):
        """Stop server"""

        server_log.info("Stopping...")

        self.manager.stop()

        res = self.api.stop()

        if 204 == res.status_code:
            server_log.info("handle_stop.api_stop: Ok")
        else:
            server_log.warning(
                "handle_stop.api_stop [%s]: %s", res.status_code, res.text
            )

        res = self.api.avail()

        if 200 == res.status_code:
            server_log.info("handle_stop.api_avail: Queue empty")
        elif 204 == res.status_code:
            server_log.info("handle_stop.api_avail: Queue not empty")
        else:
            server_log.warning(
                "handle_stop.api_avail [%s]: %s", res.status_code, res.text
            )

    def ping(self):
        """Ping websocket"""

        server_log.info("ws.ping: Started")

        while True:
            self.ws.send("ping")
            server_log.debug("ws.ping: Sent")
            threading.Event().wait(30)


class AIManager:
    """Manage UI and proxy process"""

    def __init__(self):
        self.webui = None
        self.frpc = None

    def is_running(self):
        """Check if server is running"""

        if self.webui is None and self.frpc is not None:
            server_log.warning("manager.is_running: webui is None, not possible!!!")

        return self.webui is not None or self.frpc is not None

    def start(self, uiid: str):
        """Start server"""

        host = f"{uiid}.{FRP_BASE}"
        share_url = f"https://{host}"

        self.webui = subprocess.Popen(
            [WEBUI_PATH] + WEBUI_ARGS.split(" "),
            # stdout=subprocess.PIPE,
            cwd=CWD,
            env=ENV,
            start_new_session=True,
        )

        # check port LOCAL_PORT status every 1 second, for 15 seconds
        # server timeout is 30 seconds
        tries = 15
        success = False
        server_log.info("manager.start: Waiting for server to start...")
        while tries > 0:
            tries -= 1
            t0 = time.time()
            try:
                res = requests.get(f"http://localhost:{LOCAL_PORT}", timeout=1)
                if 200 == res.status_code:
                    server_log.info(
                        "manager.start: Server started, remaining %s", tries
                    )
                    success = True
                    break
            except requests.exceptions.ConnectionError:
                pass

            remain = 1 - (time.time() - t0)
            if remain > 0:
                time.sleep(remain)

        if not success:
            server_log.error("manager.start: Failed to start server")
            os.killpg(os.getpgid(self.webui.pid), signal.SIGINT)
            self.webui.wait()
            self.webui = None
            return None

        with open("frpc.toml", "w", encoding="utf-8") as f:
            FRP_TEMPLATE["proxies"][0]["name"] = f"sdcloud_{uiid}"
            FRP_TEMPLATE["proxies"][0]["customDomains"] = [host]
            toml.dump(FRP_TEMPLATE, f)

        self.frpc = subprocess.Popen(
            [FRP_PATH, "-c", "frpc.toml"],
            stdout=subprocess.PIPE,
        )

        return share_url

    def stop(self):
        """Stop server"""

        if self.webui is not None:
            os.killpg(os.getpgid(self.webui.pid), signal.SIGINT)
            self.webui.wait()
            self.webui = None
        else:
            server_log.warning("manager.stop: No running server")

        if self.frpc is not None:
            self.frpc.terminate()
            self.frpc.wait()
            self.frpc = None
        else:
            server_log.warning("manager.stop: No running proxy")

    def cleanup(self):
        """Cleanup"""

        if self.webui is not None:
            server_log.warning("manager.cleanup: Stopping previous server...")
            os.killpg(os.getpgid(self.webui.pid), signal.SIGINT)
            self.webui.wait()
            self.webui = None
        if self.frpc is not None:
            server_log.warning("manager.cleanup: Stopping previous proxy...")
            self.frpc.terminate()
            self.frpc.wait()
            self.frpc = None


class AIApi:
    """AI server API"""

    def __init__(self, api_url, code, api_key):
        self.api_url = api_url
        self.api_data = {"code": code, "apiKey": api_key}

    def socket_token(self):
        """Get socket token"""

        return requests.post(
            f"{self.api_url}/server-connections/generate-token",
            json=self.api_data,
            timeout=10,
        ).json()["data"]["token"]

    def avail(self):
        """Server is available to serve new clients"""

        return requests.post(
            f"{self.api_url}/server-connections/available",
            json=self.api_data,
            timeout=10,
        )

    def stop(self):
        """Server is stop serving current client"""
        return requests.post(
            f"{self.api_url}/server-connections/stop-server",
            json=self.api_data,
            timeout=10,
        )

    def accept(self, ui_url):
        """Server accepted current client"""

        return requests.post(
            f"{self.api_url}/server-connections/customer-find-ai-server-result",
            json={
                **self.api_data,
                "status": "accepted",
                "url": ui_url,
            },
            timeout=10,
        )


if __name__ == "__main__":
    Wrapper(API_URL, WS_URL, SERVER_CODE, API_KEY)

